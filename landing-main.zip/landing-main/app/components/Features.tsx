"use client";

import React from "react";

const features = [
  {
    icon: (
      <svg
        width="32"
        height="32"
        viewBox="0 0 24 24"
        fill="none"
        stroke="currentColor"
        strokeWidth="1.5"
      >
        <rect x="3" y="3" width="18" height="18" rx="2" />
        <path d="M3 9h18M9 21V9" />
        <path d="M15 12l-3 3-2-2" />
      </svg>
    ),
    title: "Grade Management",
    description:
      "Track weighted averages across all semesters. Predictive analytics help you know exactly what you need on that final exam.",
  },
  {
    icon: (
      <svg
        width="32"
        height="32"
        viewBox="0 0 24 24"
        fill="none"
        stroke="currentColor"
        strokeWidth="1.5"
      >
        <rect x="3" y="4" width="18" height="18" rx="2" />
        <path d="M16 2v4M8 2v4M3 10h18" />
        <path d="M8 14h.01M12 14h.01M16 14h.01M8 18h.01M12 18h.01" />
      </svg>
    ),
    title: "Smart Scheduling",
    description:
      "Sync your syllabus with a dynamic calendar that alerts you to overlapping deadlines and provides optimal study blocks.",
  },
  {
    icon: (
      <svg
        width="32"
        height="32"
        viewBox="0 0 24 24"
        fill="none"
        stroke="currentColor"
        strokeWidth="1.5"
      >
        <path d="M12 2v20M2 12h20" />
        <circle cx="12" cy="12" r="3" fill="currentColor" stroke="none" />
      </svg>
    ),
    title: "Task Priority",
    description:
      "AI-driven prioritization based on due dates, project weight, and your historical productivity patterns.",
  },
];

export default function Features() {
  return (
    <section
      style={{
        backgroundColor: "var(--cream-light)",
        padding: "80px 24px",
      }}
    >
      <div style={{ maxWidth: 480, margin: "0 auto" }}>
        {/* Section Header */}
        <div style={{ textAlign: "center", marginBottom: 60 }}>
          <h2
            style={{
              fontFamily: "Georgia, serif",
              fontSize: "clamp(28px, 7vw, 36px)",
              fontWeight: 700,
              color: "var(--charcoal)",
              lineHeight: 1.2,
              marginBottom: 16,
            }}
          >
            Precision Tools for Success
          </h2>
          <p
            style={{
              fontFamily: "Arial, Helvetica, sans-serif",
              fontSize: 14,
              color: "var(--muted)",
              lineHeight: 1.7,
              maxWidth: 280,
              margin: "0 auto",
            }}
          >
            Built by educators and designers to streamline the cognitive load of
            student life.
          </p>
        </div>

        {/* Feature Cards */}
        <div style={{ display: "flex", flexDirection: "column", gap: 48 }}>
          {features.map((feature, i) => (
            <div
              key={i}
              style={{
                display: "flex",
                flexDirection: "column",
                alignItems: "center",
                textAlign: "center",
              }}
            >
              {/* Icon */}
              <div
                style={{
                  color: "var(--forest)",
                  marginBottom: 20,
                  opacity: 0.85,
                }}
              >
                {feature.icon}
              </div>

              {/* Title */}
              <h3
                style={{
                  fontFamily: "Georgia, serif",
                  fontSize: 20,
                  fontWeight: 700,
                  color: "var(--charcoal)",
                  marginBottom: 12,
                }}
              >
                {feature.title}
              </h3>

              {/* Description */}
              <p
                style={{
                  fontFamily: "Arial, Helvetica, sans-serif",
                  fontSize: 14,
                  color: "var(--muted)",
                  lineHeight: 1.7,
                  maxWidth: 300,
                }}
              >
                {feature.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
