"use client";

import React from "react";

export default function Hero() {
  return (
    <section
      style={{
        backgroundColor: "var(--forest)",
        minHeight: "100vh",
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        padding: "0 24px",
        paddingTop: 100,
        paddingBottom: 0,
        position: "relative",
        overflow: "hidden",
      }}
    >
      {/* Subtle radial highlight */}
      <div
        style={{
          position: "absolute",
          top: "10%",
          left: "50%",
          transform: "translateX(-50%)",
          width: 300,
          height: 300,
          borderRadius: "50%",
          background:
            "radial-gradient(circle, rgba(200,185,106,0.08) 0%, transparent 70%)",
          pointerEvents: "none",
        }}
      />

      {/* Eyebrow */}
      <div
        style={{
          display: "flex",
          alignItems: "center",
          gap: 6,
          marginBottom: 20,
        }}
      >
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#C8B96A" strokeWidth="2">
          <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2" />
        </svg>
        <span
          style={{
            color: "#C8B96A",
            fontSize: 11,
            fontFamily: "Arial, Helvetica, sans-serif",
            fontWeight: 700,
            letterSpacing: "0.12em",
            textTransform: "uppercase",
          }}
        >
          Academic Excellence 2.0
        </span>
      </div>

      {/* Headline */}
      <h1
        style={{
          color: "#F5F1E8",
          fontSize: "clamp(32px, 8vw, 44px)",
          fontFamily: "Georgia, serif",
          fontWeight: 700,
          lineHeight: 1.15,
          textAlign: "center",
          maxWidth: 360,
          marginBottom: 20,
        }}
      >
        Stay Ahead of the Curve
      </h1>

      {/* Subheadline */}
      <p
        style={{
          color: "rgba(232, 227, 216, 0.7)",
          fontSize: 15,
          fontFamily: "Arial, Helvetica, sans-serif",
          lineHeight: 1.65,
          textAlign: "center",
          maxWidth: 300,
          marginBottom: 36,
        }}
      >
        The all-in-one student tracker for grades, tasks, and schedules. Achieve
        your academic goals with surgical precision.
      </p>

      {/* CTA Button */}
      <button
        style={{
          backgroundColor: "rgba(200, 185, 106, 0.15)",
          color: "#E8E3D8",
          border: "1px solid rgba(200, 185, 106, 0.4)",
          borderRadius: 8,
          padding: "14px 40px",
          fontSize: 14,
          fontFamily: "Arial, Helvetica, sans-serif",
          fontWeight: 600,
          letterSpacing: "0.05em",
          cursor: "pointer",
          transition: "all 0.25s ease",
          marginBottom: 56,
        }}
        onMouseEnter={(e) => {
          e.currentTarget.style.backgroundColor = "rgba(200, 185, 106, 0.25)";
          e.currentTarget.style.borderColor = "rgba(200, 185, 106, 0.7)";
        }}
        onMouseLeave={(e) => {
          e.currentTarget.style.backgroundColor = "rgba(200, 185, 106, 0.15)";
          e.currentTarget.style.borderColor = "rgba(200, 185, 106, 0.4)";
        }}
      >
        Start Tracking
      </button>

      {/* Phone Mockup */}
      <div
        style={{
          width: "100%",
          maxWidth: 320,
          position: "relative",
        }}
      >
        {/* Library background image simulation */}
        <div
          style={{
            width: "100%",
            aspectRatio: "4/3",
            borderRadius: "16px 16px 0 0",
            background:
              "linear-gradient(to bottom, rgba(28,42,28,0.3) 0%, rgba(60,40,20,0.5) 100%), url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='400' height='300'%3E%3Crect width='400' height='300' fill='%23403020'/%3E%3Crect x='20' y='40' width='15' height='200' fill='%23654321'/%3E%3Crect x='38' y='60' width='12' height='180' fill='%23884422'/%3E%3Crect x='53' y='50' width='18' height='190' fill='%23553311'/%3E%3Crect x='74' y='30' width='14' height='210' fill='%23765432'/%3E%3Crect x='91' y='55' width='11' height='185' fill='%23996633'/%3E%3Crect x='105' y='45' width='16' height='195' fill='%23664422'/%3E%3Crect x='124' y='35' width='13' height='205' fill='%23775533'/%3E%3Crect x='140' y='60' width='15' height='180' fill='%23443322'/%3E%3Crect x='158' y='40' width='12' height='200' fill='%238B6914'/%3E%3Crect x='173' y='50' width='17' height='190' fill='%23654321'/%3E%3Crect x='193' y='30' width='14' height='210' fill='%23553311'/%3E%3Crect x='210' y='55' width='13' height='185' fill='%23996633'/%3E%3Crect x='226' y='45' width='15' height='195' fill='%23664422'/%3E%3Crect x='244' y='35' width='12' height='205' fill='%23775533'/%3E%3Crect x='259' y='60' width='16' height='180' fill='%23443322'/%3E%3Crect x='278' y='40' width='14' height='200' fill='%23654321'/%3E%3Crect x='295' y='50' width='11' height='190' fill='%238B6914'/%3E%3Crect x='309' y='30' width='18' height='210' fill='%23553311'/%3E%3Crect x='330' y='55' width='13' height='185' fill='%23996633'/%3E%3Crect x='346' y='45' width='15' height='195' fill='%23664422'/%3E%3Crect x='364' y='35' width='14' height='205' fill='%23775533'/%3E%3Crect x='0' y='240' width='400' height='60' fill='%23302010'/%3E%3C/svg%3E\")",
            backgroundSize: "cover",
            backgroundPosition: "center",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            overflow: "hidden",
          }}
        >
          {/* Phone device */}
          <div
            style={{
              width: 120,
              height: 220,
              backgroundColor: "#0A0A0A",
              borderRadius: 20,
              border: "3px solid #2A2A2A",
              padding: 6,
              boxShadow: "0 20px 60px rgba(0,0,0,0.7)",
              position: "relative",
            }}
          >
            {/* Notch */}
            <div
              style={{
                position: "absolute",
                top: 6,
                left: "50%",
                transform: "translateX(-50%)",
                width: 30,
                height: 6,
                backgroundColor: "#0A0A0A",
                borderRadius: 3,
                zIndex: 2,
              }}
            />
            {/* Screen */}
            <div
              style={{
                width: "100%",
                height: "100%",
                backgroundColor: "#111A14",
                borderRadius: 14,
                overflow: "hidden",
                padding: 8,
              }}
            >
              {/* App content */}
              <div style={{ color: "#C8B96A", fontSize: 5, fontFamily: "Arial", marginBottom: 4 }}>
                Scholarly
              </div>
              {[
                { label: "CS301 Algorithms", val: "87%" },
                { label: "MATH201 Calculus", val: "92%" },
                { label: "ENG102 Writing", val: "79%" },
                { label: "PHYS101 Physics", val: "84%" },
              ].map((item, i) => (
                <div
                  key={i}
                  style={{
                    display: "flex",
                    justifyContent: "space-between",
                    alignItems: "center",
                    backgroundColor: "rgba(200,185,106,0.08)",
                    borderRadius: 4,
                    padding: "3px 5px",
                    marginBottom: 3,
                  }}
                >
                  <span style={{ color: "#9AB09A", fontSize: 4, fontFamily: "Arial" }}>
                    {item.label}
                  </span>
                  <span style={{ color: "#C8B96A", fontSize: 5, fontFamily: "Arial", fontWeight: "bold" }}>
                    {item.val}
                  </span>
                </div>
              ))}
              <div
                style={{
                  marginTop: 6,
                  backgroundColor: "rgba(200,185,106,0.12)",
                  borderRadius: 4,
                  padding: 4,
                }}
              >
                <div style={{ color: "#7A9A7A", fontSize: 4, fontFamily: "Arial", marginBottom: 2 }}>
                  Next deadline
                </div>
                <div style={{ color: "#E8E3D8", fontSize: 5, fontFamily: "Arial" }}>
                  CS301 Assignment 3
                </div>
                <div style={{ color: "#C8B96A", fontSize: 4, fontFamily: "Arial" }}>
                  Due in 2 days
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
