"use client";

import React from "react";

export default function Footer() {
  const links = [
    ["Privacy Policy", "Terms of Service", "Help Center"],
    ["Contact Us"],
  ];

  return (
    <footer
      style={{
        backgroundColor: "var(--cream)",
        borderTop: "1px solid rgba(90, 106, 90, 0.15)",
        padding: "48px 24px 32px",
      }}
    >
      <div
        style={{
          maxWidth: 480,
          margin: "0 auto",
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          gap: 0,
        }}
      >
        {/* Logo */}
        <div
          style={{
            display: "flex",
            alignItems: "center",
            gap: 8,
            color: "var(--forest)",
            marginBottom: 12,
          }}
        >
          <svg
            width="18"
            height="18"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
          >
            <path d="M22 10v6M2 10l10-5 10 5-10 5z" />
            <path d="M6 12v5c3 3 9 3 12 0v-5" />
          </svg>
          <span
            style={{
              fontFamily: "Georgia, serif",
              fontSize: 18,
              fontWeight: 700,
            }}
          >
            Scholarly
          </span>
        </div>

        {/* Tagline */}
        <p
          style={{
            fontFamily: "Arial, Helvetica, sans-serif",
            fontSize: 13,
            color: "var(--muted)",
            textAlign: "center",
            lineHeight: 1.6,
            maxWidth: 260,
            marginBottom: 28,
          }}
        >
          Empowering students to reach their full potential through organizational excellence.
        </p>

        {/* Nav links row 1 */}
        <div
          style={{
            display: "flex",
            flexWrap: "wrap",
            justifyContent: "center",
            gap: "8px 20px",
            marginBottom: 8,
          }}
        >
          {links[0].map((link) => (
            <a
              key={link}
              href="#"
              style={{
                fontFamily: "Arial, Helvetica, sans-serif",
                fontSize: 12,
                color: "var(--muted)",
                textDecoration: "none",
                transition: "color 0.2s ease",
              }}
              onMouseEnter={(e) =>
                (e.currentTarget.style.color = "var(--forest)")
              }
              onMouseLeave={(e) =>
                (e.currentTarget.style.color = "var(--muted)")
              }
            >
              {link}
            </a>
          ))}
        </div>

        {/* Nav links row 2 */}
        <div style={{ marginBottom: 32 }}>
          {links[1].map((link) => (
            <a
              key={link}
              href="#"
              style={{
                fontFamily: "Arial, Helvetica, sans-serif",
                fontSize: 12,
                color: "var(--muted)",
                textDecoration: "none",
                transition: "color 0.2s ease",
              }}
              onMouseEnter={(e) =>
                (e.currentTarget.style.color = "var(--forest)")
              }
              onMouseLeave={(e) =>
                (e.currentTarget.style.color = "var(--muted)")
              }
            >
              {link}
            </a>
          ))}
        </div>

        {/* Copyright */}
        <p
          style={{
            fontFamily: "Arial, Helvetica, sans-serif",
            fontSize: 11,
            color: "rgba(90, 106, 90, 0.6)",
            textAlign: "center",
          }}
        >
          © 2024 Scholarly Tracker. All academic rights reserved.
        </p>
      </div>
    </footer>
  );
}
