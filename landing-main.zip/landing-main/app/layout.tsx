import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Scholarly — Academic Excellence 2.0",
  description:
    "The all-in-one student tracker for grades, tasks, and schedules. Achieve your academic goals with surgical precision.",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
